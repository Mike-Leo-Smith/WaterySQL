//
// Created by Mike Smith on 2018/11/25.
//

#ifndef WATERYSQL_INDEX_HEADER_H
#define WATERYSQL_INDEX_HEADER_H

#include <cstdint>
#include "../config/config.h"
#include "../data_storage/data_descriptor.h"

namespace watery {

struct IndexHeader {
    
    DataDescriptor key_descriptor;
    uint32_t page_count;
    uint32_t key_length;
    uint32_t pointer_length;
    uint32_t key_count_per_node;
    PageOffset root_offset;
};

}

#endif  // WATERYSQL_INDEX_HEADER_H
